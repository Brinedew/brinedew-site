;(function (root) {
  "use strict"

  // Chesterton's fence: this matcher scores text against published data only. Broad
  // HGNC coverage belongs in the workstation export; deliberately curated page
  // labels belong in the administrator-owned publication-alias manifest overlay. Do not
  // teach the content script to guess missing biology facts on its own.

  const LETTER_OR_NUMBER_RE = /[\p{L}\p{N}]/u

  function normalizeSymbol(rawSymbol) {
    return String(rawSymbol || "")
      .trim()
      .toUpperCase()
  }

  function normalizeBlocklistTerm(rawTerm) {
    return String(rawTerm || "")
      .trim()
      .replace(/[\u2010-\u2015\u2212]/g, "-")
      .toUpperCase()
  }

  function normalizeBlocklist(rawBlocklist) {
    const values =
      Array.isArray(rawBlocklist) || rawBlocklist instanceof Set
        ? [...rawBlocklist]
        : rawBlocklist && typeof rawBlocklist[Symbol.iterator] === "function"
          ? Array.from(rawBlocklist)
          : []
    return new Set(values.map(normalizeBlocklistTerm).filter(Boolean))
  }

  function normalizeAliasKey(rawAlias) {
    return String(rawAlias || "")
      .trim()
      .replace(/[\u2010-\u2015\u2212]/g, "-")
  }

  function foldAliasTextForScan(rawText) {
    return String(rawText || "").replace(/[\u2010-\u2015\u2212]/g, "-")
  }

  function isUppercaseLetterCode(code) {
    return code >= 65 && code <= 90
  }

  function isDigitCode(code) {
    return code >= 48 && code <= 57
  }

  function isCoreGeneCharCode(code) {
    return isUppercaseLetterCode(code) || isDigitCode(code)
  }

  function isGeneTokenChar(text, index) {
    if (index < 0 || index >= text.length) return false
    const code = text.charCodeAt(index)
    if (isCoreGeneCharCode(code)) return true
    if (code !== 45) return false
    if (index <= 0 || index >= text.length - 1) return false
    return (
      isCoreGeneCharCode(text.charCodeAt(index - 1)) &&
      isCoreGeneCharCode(text.charCodeAt(index + 1))
    )
  }

  function hasLeftBoundary(text, index) {
    if (index <= 0) return true
    return !isLetterOrNumber(text, index - 1)
  }

  function hasRightBoundary(text, index) {
    if (index >= text.length) return true
    return !isLetterOrNumber(text, index)
  }

  function finishSteps(steps) {
    let step
    do {
      step = steps.next()
    } while (!step.done)
    return step.value
  }

  function buildTrie(symbols, normalizeToken) {
    return finishSteps(buildTrieSteps(symbols, normalizeToken))
  }

  function* buildTrieSteps(symbols, normalizeToken) {
    const rootNode = { children: Object.create(null), terminal: "" }
    const normalizer = typeof normalizeToken === "function" ? normalizeToken : normalizeSymbol
    for (const rawSymbol of Array.isArray(symbols) ? symbols : []) {
      const symbol = normalizer(rawSymbol)
      if (!symbol) continue
      let node = rootNode
      for (let i = 0; i < symbol.length; i += 1) {
        const ch = symbol.charAt(i)
        if (!node.children[ch]) {
          node.children[ch] = { children: Object.create(null), terminal: "" }
        }
        node = node.children[ch]
      }
      node.terminal = symbol
      yield
    }
    return rootNode
  }

  function buildAliasLookup(geneMap) {
    return finishSteps(buildAliasLookupSteps(geneMap))
  }

  function* buildAliasLookupSteps(geneMap) {
    const lookup = Object.create(null)
    const duplicates = new Set()
    const safeGeneMap = geneMap && typeof geneMap === "object" ? geneMap : {}
    for (const symbol of Object.keys(safeGeneMap)) {
      const aliases = Array.isArray(safeGeneMap[symbol] && safeGeneMap[symbol].a)
        ? safeGeneMap[symbol].a
        : []
      for (const rawAlias of aliases) {
        const aliasKey = normalizeAliasKey(rawAlias)
        if (!aliasKey || aliasKey === symbol || safeGeneMap[aliasKey]) continue
        if (duplicates.has(aliasKey)) continue
        if (lookup[aliasKey] && lookup[aliasKey] !== symbol) {
          delete lookup[aliasKey]
          duplicates.add(aliasKey)
          continue
        }
        lookup[aliasKey] = symbol
      }
      yield
    }
    return lookup
  }

  function compareCandidateLists(left, right) {
    const leftList = Array.isArray(left) ? left : []
    const rightList = Array.isArray(right) ? right : []
    const leftScore = leftList.reduce((sum, item) => sum + (Number(item && item.length) || 0), 0)
    const rightScore = rightList.reduce((sum, item) => sum + (Number(item && item.length) || 0), 0)
    if (leftScore !== rightScore) return leftScore - rightScore
    if (leftList.length !== rightList.length) return rightList.length - leftList.length
    for (let i = 0; i < Math.min(leftList.length, rightList.length); i += 1) {
      const byStart =
        (Number(rightList[i] && rightList[i].index) || 0) -
        (Number(leftList[i] && leftList[i].index) || 0)
      if (byStart !== 0) return byStart
      const byLength =
        (Number(leftList[i] && leftList[i].length) || 0) -
        (Number(rightList[i] && rightList[i].length) || 0)
      if (byLength !== 0) return byLength
    }
    return 0
  }

  function selectBestRunCandidates(candidates) {
    const sorted = sortCandidates(candidates)
    const memo = new Map()

    function solve(index) {
      if (index >= sorted.length) return []
      if (memo.has(index)) return memo.get(index)

      const skipped = solve(index + 1)
      const current = sorted[index]
      const currentEnd =
        (Number(current && current.index) || 0) + (Number(current && current.length) || 0)
      let nextIndex = index + 1
      while (nextIndex < sorted.length) {
        const nextStart = Number(sorted[nextIndex] && sorted[nextIndex].index) || 0
        if (nextStart >= currentEnd) break
        nextIndex += 1
      }
      const taken = [current].concat(solve(nextIndex))
      const best = compareCandidateLists(taken, skipped) >= 0 ? taken : skipped
      memo.set(index, best)
      return best
    }

    return solve(0)
  }

  function collectRunCandidates(tokenText, runOffset, trieRoot) {
    const source = String(tokenText || "")
    if (!source || !trieRoot) return []
    const candidates = []

    for (let start = 0; start < source.length; start += 1) {
      if (start > 0 && source.charAt(start - 1) !== "-") continue
      let node = trieRoot
      let cursor = start
      while (cursor < source.length) {
        const ch = source.charAt(cursor)
        node = node.children[ch]
        if (!node) break
        cursor += 1
        if (node.terminal && (cursor === source.length || source.charAt(cursor) === "-")) {
          candidates.push({
            symbol: node.terminal,
            index: runOffset + start,
            length: cursor - start,
            text: source.slice(start, cursor),
          })
        }
      }
    }

    return selectBestRunCandidates(candidates)
  }

  function collectCandidates(text, trieRoot) {
    const source = String(text || "")
    if (!source || !trieRoot) return []

    const matches = []
    let index = 0
    while (index < source.length) {
      const firstCode = source.charCodeAt(index)
      if (!isUppercaseLetterCode(firstCode) || !hasLeftBoundary(source, index)) {
        index += 1
        continue
      }

      let runEnd = index
      while (runEnd < source.length && isGeneTokenChar(source, runEnd)) {
        runEnd += 1
      }
      if (!hasRightBoundary(source, runEnd)) {
        index = Math.max(runEnd, index + 1)
        continue
      }
      const runText = source.slice(index, runEnd)
      const runMatches = collectRunCandidates(runText, index, trieRoot)
      if (runMatches.length) {
        matches.push(...runMatches)
      }
      index = Math.max(runEnd, index + 1)
    }

    return matches
  }

  function isLetterOrNumber(text, index) {
    if (index < 0 || index >= text.length) return false
    return LETTER_OR_NUMBER_RE.test(text.charAt(index))
  }

  function hasAliasLeftBoundary(text, index) {
    if (index <= 0) return true
    return !isLetterOrNumber(text, index - 1)
  }

  function hasAliasRightBoundary(text, index) {
    if (index >= text.length) return true
    return !isLetterOrNumber(text, index)
  }

  function collectAliasCandidates(text, trieRoot, aliasLookup) {
    const source = String(text || "")
    if (!source || !trieRoot || !aliasLookup) return []
    const folded = foldAliasTextForScan(source)
    const matches = []
    let index = 0

    while (index < folded.length) {
      if (!hasAliasLeftBoundary(source, index)) {
        index += 1
        continue
      }

      let node = trieRoot
      let cursor = index
      let bestCandidate = null

      while (cursor < folded.length) {
        const ch = folded.charAt(cursor)
        node = node.children[ch]
        if (!node) break
        cursor += 1

        if (node.terminal && hasAliasRightBoundary(source, cursor)) {
          const symbol = aliasLookup[node.terminal]
          if (symbol) {
            bestCandidate = {
              symbol,
              index,
              length: cursor - index,
              text: source.slice(index, cursor),
              matchedBy: "alias",
            }
          }
        }
      }

      if (bestCandidate) {
        matches.push(bestCandidate)
        index = bestCandidate.index + bestCandidate.length
        continue
      }

      index += 1
    }

    return matches
  }

  function foldBlocklistTextForScan(rawText) {
    const source = String(rawText || "")
    let folded = ""
    const originalStarts = []
    const originalEnds = []

    for (let index = 0; index < source.length;) {
      const codePoint = source.codePointAt(index)
      const character = String.fromCodePoint(codePoint)
      const characterEnd = index + character.length
      const normalized = character.replace(/[\u2010-\u2015\u2212]/g, "-").toUpperCase()
      folded += normalized
      for (let offset = 0; offset < normalized.length; offset += 1) {
        originalStarts.push(index)
        originalEnds.push(characterEnd)
      }
      index = characterEnd
    }

    return { folded, originalStarts, originalEnds }
  }

  function collectBlockedSpans(text, trieRoot) {
    const source = String(text || "")
    if (!source || !trieRoot) return []
    const { folded, originalStarts, originalEnds } = foldBlocklistTextForScan(source)
    const spans = []

    for (let start = 0; start < folded.length; start += 1) {
      // Unicode uppercase expansion can produce multiple folded code units for one
      // source character. A blocklisted phrase may start only at a real source
      // character boundary so reported spans always map back to the DOM exactly.
      if (start > 0 && originalStarts[start] === originalStarts[start - 1]) continue
      const originalStart = originalStarts[start]
      if (!hasAliasLeftBoundary(source, originalStart)) continue

      let node = trieRoot
      let cursor = start
      while (cursor < folded.length) {
        node = node.children[folded.charAt(cursor)]
        if (!node) break
        cursor += 1
        const endsAtSourceBoundary =
          cursor === folded.length || originalStarts[cursor] !== originalStarts[cursor - 1]
        if (!node.terminal || !endsAtSourceBoundary) continue
        const originalEnd = originalEnds[cursor - 1]
        if (!hasAliasRightBoundary(source, originalEnd)) continue
        spans.push({
          index: originalStart,
          length: originalEnd - originalStart,
          text: source.slice(originalStart, originalEnd),
          term: node.terminal,
        })
      }
    }

    return spans
  }

  function overlapsBlockedSpan(candidate, blockedSpans) {
    const start = Number(candidate && candidate.index) || 0
    const end = start + (Number(candidate && candidate.length) || 0)
    for (const span of Array.isArray(blockedSpans) ? blockedSpans : []) {
      const left = Number(span && span.index) || 0
      const right = left + (Number(span && span.length) || 0)
      if (start < right && end > left) return true
    }
    return false
  }

  function filterCandidates(candidates, options) {
    const opts = options && typeof options === "object" ? options : {}
    const geneMap = opts.geneMap && typeof opts.geneMap === "object" ? opts.geneMap : null
    // Single blocklist Set — the caller (content.js) merges defaults + user choices
    // into one set, so the matcher just blocks whatever it's told to block.
    const blocklist =
      opts.blocklist instanceof Set ? opts.blocklist : normalizeBlocklist(opts.blocklist)
    const accepted = []

    for (const candidate of Array.isArray(candidates) ? candidates : []) {
      const symbol = normalizeSymbol(candidate && candidate.symbol)
      if (!symbol) continue
      if (geneMap && !geneMap[symbol]) continue
      const candidateText = String(candidate.text || symbol)
      const candidateKey = normalizeSymbol(candidateText)
      if (blocklist.has(candidateKey) || blocklist.has(symbol)) continue
      accepted.push({
        symbol,
        index: Number(candidate.index || 0),
        length: Number(candidate.length || symbol.length),
        text: candidateText,
        matchedBy: String(candidate.matchedBy || "symbol"),
      })
    }

    return accepted
  }

  function sortCandidates(candidates) {
    return [...(Array.isArray(candidates) ? candidates : [])].sort((left, right) => {
      const leftIndex = Number(left && left.index) || 0
      const rightIndex = Number(right && right.index) || 0
      if (leftIndex !== rightIndex) return leftIndex - rightIndex
      const leftLength = Number(left && left.length) || 0
      const rightLength = Number(right && right.length) || 0
      return rightLength - leftLength
    })
  }

  function overlapsAccepted(candidate, accepted) {
    const start = Number(candidate && candidate.index) || 0
    const end = start + (Number(candidate && candidate.length) || 0)
    for (const match of Array.isArray(accepted) ? accepted : []) {
      const left = Number(match && match.index) || 0
      const right = left + (Number(match && match.length) || 0)
      if (start < right && end > left) return true
    }
    return false
  }

  function createGeneMatcher(geneMap, options) {
    return finishSteps(createGeneMatcherSteps(geneMap, options))
  }

  // One lexical implementation, two schedulers. Cached recognition must not
  // turn building the 19k-gene tries into a long host-rendering task.
  function createGeneMatcherCooperatively(geneMap, options, windowRef = root) {
    const steps = createGeneMatcherSteps(geneMap, options)
    return new Promise((resolve, reject) => {
      const schedule = () => {
        root.IconoplasmContentLifecycle.scheduleRecognitionWork(run, { windowRef })
      }
      const run = (deadline) => {
        try {
          const now = () => windowRef.performance?.now?.() ?? Date.now()
          const start = now()
          let count = 0
          const loaded = windowRef.document?.readyState === "complete"
          const sliceBudgetMs = loaded ? 4 : 8
          // Required startup cannot pay a scheduling delay for each 32-token
          // chunk: on busy chat pages that stretches a small build into minutes.
          // Use at most 4 ms per yielding task after load, without an idle gate.
          // Stay below half a 60-Hz frame and stop earlier if idle time runs out.
          // Smaller quanta pay Chrome's idle rescheduling gap for every chunk.
          while (
            now() - start < sliceBudgetMs &&
            (loaded || !deadline || deadline.timeRemaining() > 2)
          ) {
            // Checking the clock for each trie character/token costs more than
            // inserting it. Amortize checks over a bounded 32-token chunk.
            do {
              const step = steps.next()
              if (step.done) {
                resolve(step.value)
                return
              }
              count++
            } while (count % 32 !== 0)
          }
          schedule()
        } catch (error) {
          reject(error)
        }
      }
      schedule()
    })
  }

  function* createGeneMatcherSteps(geneMap, options) {
    const safeGeneMap = geneMap && typeof geneMap === "object" ? geneMap : {}
    const exactTrie = yield* buildTrieSteps(Object.keys(safeGeneMap))
    const aliasLookup = yield* buildAliasLookupSteps(safeGeneMap)
    // Fence: alias hover matching must stay case-sensitive. The extension's job is
    // to instrument symbol-like tokens, not to reinterpret ordinary English prose
    // after case-folding it into an all-caps gene namespace. Upstream publication
    // should emit the exact alias spellings we want to recognize on-page.
    const aliasTrie = yield* buildTrieSteps(Object.keys(aliasLookup), normalizeAliasKey)
    const blocklist = normalizeBlocklist(options && options.blocklist)
    const blocklistTrie = blocklist.size
      ? yield* buildTrieSteps([...blocklist], normalizeBlocklistTerm)
      : null
    const matcherOptions = Object.assign({}, options || {}, {
      geneMap: safeGeneMap,
      blocklist,
    })
    return {
      collectCandidates(text) {
        return collectCandidates(text, exactTrie)
      },
      collectAliasCandidates(text) {
        return collectAliasCandidates(text, aliasTrie, aliasLookup)
      },
      filterCandidates(candidates) {
        return filterCandidates(candidates, matcherOptions)
      },
      hasBlocklist() {
        return !!blocklistTrie
      },
      findMatches(text, surroundings = null) {
        // A blocklist entry protects its complete source span. This is stronger
        // than candidate equality: APC/C suppresses the otherwise-valid APC
        // symbol inside it, while a standalone APC remains eligible.
        // `surroundings` is the visible text just before and after this text node
        // (B-1005): a page that writes PIP<sub>3</sub> splits the protected phrase
        // PIP3 across two nodes. Only protected phrases read it; gene candidates
        // still come from this node's own text.
        const before = String(surroundings?.before || "")
        const after = String(surroundings?.after || "")
        const blockedSpans =
          before || after
            ? collectBlockedSpans(before + text + after, blocklistTrie).map((span) =>
                Object.assign({}, span, { index: span.index - before.length }),
              )
            : collectBlockedSpans(text, blocklistTrie)
        const acceptedExact = sortCandidates(
          filterCandidates(collectCandidates(text, exactTrie), matcherOptions),
        ).filter((candidate) => !overlapsBlockedSpan(candidate, blockedSpans))
        const aliasCandidates = sortCandidates(
          filterCandidates(collectAliasCandidates(text, aliasTrie, aliasLookup), matcherOptions),
        ).filter((candidate) => !overlapsBlockedSpan(candidate, blockedSpans))
        // Fence: exact canonical symbols win. The alias layer only fills empty spans so
        // `NFKB1` still beats `NF-κB`-style convenience names when both could plausibly fire.
        const accepted = [...acceptedExact]
        for (const candidate of aliasCandidates) {
          if (overlapsAccepted(candidate, accepted)) continue
          accepted.push(candidate)
        }
        return sortCandidates(accepted)
      },
    }
  }

  const api = {
    buildTrie,
    buildAliasLookup,
    collectCandidates,
    collectAliasCandidates,
    filterCandidates,
    createGeneMatcher,
    createGeneMatcherCooperatively,
  }

  root.IconoplasmContentMatcher = api
})(typeof globalThis !== "undefined" ? globalThis : this)
